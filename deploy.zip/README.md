# 🎛️ Discord bot — Viht VPN

Viht VPN — современный Discord‑бот для управления AI‑чатом, автоматизации сервера и взаимодействия с сообществом.

Коротко о возможностях
- 🤖 AI‑чат: команда `/viht` позволяет быстро получить помощь по настройке VPN, вопросам по проекту и техническим задачам.
- 🎉 Приветственное сообщение с реакцией: пользователи ставят ✅, чтобы получить роль **Подписчик**.
- 🏛️ Dashboard: панель управления с личным кабинетом, голосованиями и админскими инструментами.
- 📡 Утилиты сети: быстрые команды для базовой диагностики (узнать IP, провести простую проверку скорости), чтобы быстрее помогать пользователям.

Описание
-------
Этот репозиторий содержит минимальный, но расширяемый проект бота Viht VPN:

- AI‑чат (Gemini) для ответов и подсказок;
- Система приветствия с реакциями для выдачи ролей;
- Небольшой dashboard с кнопками/вкладками (личный кабинет, государственная дума / голосования, магазин (в разработке)).

Контакты
--------
Для создания бота, интеграций или коммерческой поддержки обращайтесь к разработчику Viht:

🔗 https://t.me/anviht

Запуск локально
----------------
1. Скопируйте `.env.example` → `.env` и заполните значения:

```
DISCORD_TOKEN=ВАШ_DISCORD_TOKEN
CLIENT_ID=ВАШ_CLIENT_ID
GUILD_ID=ВАШ_GUILD_ID    # опционно
GEMINI_API_KEY=ВАШ_GEMINI_KEY
WELCOME_CHANNEL_ID=ВАШ_WELCOME_CHANNEL_ID
PORT=3001
```

2. Установите зависимости:

```powershell
npm ci
```

3. (Опционально) Зарегистрируйте slash‑команды:

```powershell
npm run register-commands
```

4. Тестовый запуск:

```powershell
DISCORD_TOKEN="..." GEMINI_API_KEY="..." npm start
```

Где взять ID и токены
---------------------
- **Application ID (CLIENT_ID)**: Discord Developer Portal → General Information → Copy ID
- **Bot Token (DISCORD_TOKEN)**: Developer Portal → Bot → Reset Token → Copy token и поместить в `.env`
- **GUILD_ID**: Developer Mode → правый клик по серверу → Copy ID
- **WELCOME_CHANNEL_ID**: Developer Mode → правый клик по каналу → Copy ID

Развёртывание / Хостинг
-----------------------
GitHub Actions не предназначены для хостинга долгоживущих процессов (лимит 1 час). Рекомендуемые варианты:

- ✅ VPS + `systemd` (надежно)
- ✅ VPS + `pm2` (удобно для логов и автоперезапуска)
- ✅ PaaS (Render, Railway, Fly) — быстрое развёртывание через GitHub

В репозитории есть `deploy/` с примерами `pm2` и `systemd` конфигураций.

Полезные команды (Ubuntu / bash)

```bash
cd /path/to/repo
npm ci
# тест
DISCORD_TOKEN="..." GEMINI_API_KEY="..." npm start

# PM2
npm i -g pm2
pm2 start deploy/pm2.config.js --env production
pm2 save

# systemd (после правки deploy/viht-bot.service)
sudo cp deploy/viht-bot.service /etc/systemd/system/viht-bot.service
sudo systemctl daemon-reload
sudo systemctl enable --now viht-bot
sudo journalctl -u viht-bot -f
```

Идеи для улучшений
------------------
- Централизованное логирование (winston) и канал аудита для важных событий (выдача ролей, голосования).
- Dockerfile для контейнерного развёртывания.
- Полный рабочий цикл голосований: автоматическое завершение, подсчёт и назначение президента с уведомлениями.
- Расширенный набор сетевых утилит в dashboard (speedtest, tracert и т.д.).

Вклад и коммерческие запросы
---------------------------
Форк и пул‑реквесты приветствуются. Для коммерческих запросов и кастомной доработки пишите: https://t.me/anviht

Спасибо за использование Viht VPN! 🚀

