const { getMusicButtonHandler } = require('./musicHandler');

module.exports = {
  getMusicButtonHandler
};
