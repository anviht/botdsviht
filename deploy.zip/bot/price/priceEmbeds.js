const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

function createPriceMainEmbed() {
  return new EmbedBuilder()
    .setTitle('📜 Прайс — Информация об услугах')
    .setColor(0x5B9CFA)
    .setDescription('Приветствую, уважаемые подписчики! Мы помогаем автоматизировать рутинные задачи и развивать вашу инфраструктуру в интернете — сайты, боты и сложные веб‑сервисы. Ниже выберите категорию, чтобы получить подробную информацию.')
    .setFooter({ text: 'Для заказа — создайте тикет в службе поддержки.' });
}

function getMainRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('price_site').setLabel('🌐 Сайт').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('price_bot').setLabel('🤖 Бот').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('price_other').setLabel('🛠️ Иное').setStyle(ButtonStyle.Secondary)
  );
}

function createSiteEmbed() {
  return new EmbedBuilder()
    .setTitle('🌐 Сайты и веб‑решения')
    .setColor(0x47D7AC)
    .setDescription('Мы делаем не просто сайты — мы строим автоматизированные сервисы. В комплект может входить: одностраничный лендинг, функциональный многостраничный сайт, мини‑магазин или многопользовательская платформа.\\n\\nКаждый проект получает административную панель для управления контентом и аналитики, а также интеграцию с ИИ для автоматизации задач (модерация, генерация контента, ответы на запросы).\\n\\nЧтобы обсудить заказ и сроки, создайте тикет в службе поддержки: <#1442575929044897792>')
    .setFooter({ text: 'Нажмите «← Назад», чтобы вернуться к меню.' });
}

function createBotEmbed() {
  return new EmbedBuilder()
    .setTitle('🤖 Боты и автоматизация')
    .setColor(0x9F7AEA)
    .setDescription('Мы разрабатываем ботов для Discord, Telegram, WhatsApp, веб‑приложений и других платформ. Боты могут: выполнять команды, обрабатывать обращения, интегрироваться с ML/AI‑модулями для интеллектуальных ответов и автоматических рабочих процессов.\\n\\nПримеры: служебные помощники, модерация, уведомления, интеграции с CRM/платежами. Для заказа создайте тикет в службе поддержки: <#1442575929044897792>')
    .setFooter({ text: 'Нажмите «← Назад», чтобы вернуться к меню.' });
}

function createOtherEmbed() {
  return new EmbedBuilder()
    .setTitle('🛠️ Другие сервисы')
    .setColor(0xFFC857)
    .setDescription('Мы также можем предоставить более сложные решения: VPN‑сервисы с управлением, игровые серверы, интеграции с онлайн‑кассами и прочие облачные сервисы с веб‑панелью для администраторов и пользователей.\\n\\nТакие продукты проектируются под ваши требования и включают интерфейсы управления, диалоговые окна и полноценную автоматизацию. Для деталей и заказа создайте тикет: <#1442575929044897792>')
    .setFooter({ text: 'Нажмите «← Назад», чтобы вернуться к меню.' });
}

function getBackRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('price_back').setLabel('← Назад').setStyle(ButtonStyle.Danger)
  );
}

module.exports = {
  createPriceMainEmbed,
  getMainRow,
  createSiteEmbed,
  createBotEmbed,
  createOtherEmbed,
  getBackRow
};
